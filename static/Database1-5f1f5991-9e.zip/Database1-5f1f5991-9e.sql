-- Access Converter
-- version 1.1.1
-- author Christos Lytras <christos.lytras@gmail.com>
-- https://lytrax.io/blog/tools/access-converter
--
-- Generation time: Mon 27, 2020 at 10:47 PM

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `Clientes`
--

CREATE TABLE IF NOT EXISTS `Clientes` (
  `ID_Usuario` INT(10) UNSIGNED NOT NULL,
  `Fecha_Creación` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sesion` DOUBLE NOT NULL DEFAULT '0',
  `Usuario` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `Correo` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `Contraseña` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `Clientes`
--

INSERT INTO `Clientes` (`ID_Usuario`, `Fecha_Creación`, `sesion`, `Usuario`, `Correo`, `Contraseña`) VALUES
(2, '2020-04-14 00:00:00', 1.0, 'admin', 'ejemplo@hotmail.com', 'adnub');
--
-- Indexes for table `Clientes`
--
ALTER TABLE `Clientes`
  ADD PRIMARY KEY (`ID_Usuario`);

--
-- AUTO_INCREMENT for table `Clientes`
--
ALTER TABLE `Clientes`
  MODIFY `ID_Usuario` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Table structure for table `Comentarios`
--

CREATE TABLE IF NOT EXISTS `Comentarios` (
  `ID_Comentario` INT(10) UNSIGNED NOT NULL,
  `Asunto` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `Comentario` VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `Fecha` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ID_Usuario` INT(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for table `Clientes`
--
ALTER TABLE `Clientes`
  ADD PRIMARY KEY (`ID_Usuario`);

--
-- AUTO_INCREMENT for table `Clientes`
--
ALTER TABLE `Clientes`
  MODIFY `ID_Usuario` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Indexes for table `Comentarios`
--
ALTER TABLE `Comentarios`
  ADD PRIMARY KEY (`ID_Comentario`);

--
-- AUTO_INCREMENT for table `Comentarios`
--
ALTER TABLE `Comentarios`
  MODIFY `ID_Comentario` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

